package com.example.web3project

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class Web3Application : Application() 