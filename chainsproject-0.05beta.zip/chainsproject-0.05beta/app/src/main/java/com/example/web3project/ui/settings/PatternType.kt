package com.example.web3project.ui.settings

enum class PatternType {
    SQUARE,
    CIRCLE,
    HEXAGON
} 